﻿namespace McProtoNet
{
	public enum ClientState
	{
		None,
		Connecting,
		HandShake,
		Login,
		Play,
		Failed
	}
}