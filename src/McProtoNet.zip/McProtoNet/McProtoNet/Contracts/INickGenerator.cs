﻿namespace McProtoNet.Contracts
{
	public interface INickGenerator
	{
		public string Generate();
	}
}
