﻿namespace McProtoNet
{
	public enum SubProtocol
	{
		HandShake,
		Login,
		Game
	}
}