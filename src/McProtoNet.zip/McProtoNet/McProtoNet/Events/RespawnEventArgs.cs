﻿namespace McProtoNet.Events
{
	public class RespawnEventArgs : EventArgs
	{
	}
}
