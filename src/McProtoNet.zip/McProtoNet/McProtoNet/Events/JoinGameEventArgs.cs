﻿namespace McProtoNet.Events
{
	public class JoinGameEventArgs : EventArgs
	{

	}
}
