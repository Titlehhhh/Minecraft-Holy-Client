﻿namespace McProtoNet.Events
{
	public class DisconnectEventArgs : EventArgs
	{
		public string Reason { get; internal set; }

		
	}
}
