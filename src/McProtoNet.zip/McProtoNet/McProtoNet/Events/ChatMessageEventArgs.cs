﻿namespace McProtoNet.Events
{
	public class ChatMessageEventArgs : EventArgs
	{
		public string Message { get; internal set; }

		
	}
}
