﻿namespace McProtoNet
{
	public class MapData
	{
		public byte Columns { get; internal set; }
		public byte Rows { get; internal set; }
		public byte X { get; internal set; }
		public byte Y { get; internal set; }
		public byte[] Data { get; internal set; }

		
	}
}
