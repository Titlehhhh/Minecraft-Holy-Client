﻿using McProtoNet.Core.IO;
using McProtoNet.Core.Protocol;

namespace McProtoNet.Core
{
	public sealed class StatusQueryPacket : MinecraftPacket
	{
		public override void Read(IMinecraftPrimitiveReader stream)
		{

		}

		public override void Write(IMinecraftPrimitiveWriter stream)
		{

		}
	}
}