﻿namespace McProtoNet.Core.Protocol
{
	public interface ISwitchCompression
	{
		void SwitchCompression(int threshold);
	}
}

