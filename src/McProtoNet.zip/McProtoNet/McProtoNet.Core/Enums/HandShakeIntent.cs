﻿namespace McProtoNet.Core
{
	public enum HandShakeIntent : int
	{
		STATUS = 1,
		LOGIN = 2
	}

}
