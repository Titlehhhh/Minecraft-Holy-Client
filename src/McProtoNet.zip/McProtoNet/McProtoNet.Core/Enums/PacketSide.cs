﻿namespace McProtoNet.Core
{
	public enum PacketSide
	{
		Client,
		Server
	}

}
