﻿namespace McProtoNet.Core
{
	public enum ContainerTypeOld
	{
		CONTAINER,
		CHEST,
		CRAFTING_TABLE,
		FURNACE,
		DISPENSER,
		ENCHANTING_TABLE,
		BREWING_STAND,
		VILLAGER,
		BEACON,
		ANVIL,
		HOPPER,
		DROPPER,
		SHULKER_BOX,
		ENTITYHORSE
	}
}
