﻿namespace McProtoNet.Core
{
	public enum PacketCategory
	{
		HandShake,
		Status,
		Login,
		Game
	}


}
