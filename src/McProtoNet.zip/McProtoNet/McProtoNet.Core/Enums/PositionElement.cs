﻿namespace McProtoNet.Core
{
	public enum PositionElement : int
	{
		X = 0,
		Y = 1,
		Z = 2,
		Pitch = 3,
		Yaw = 4

	}

}
