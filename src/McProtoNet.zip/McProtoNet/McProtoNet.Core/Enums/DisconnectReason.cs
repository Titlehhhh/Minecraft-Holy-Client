﻿namespace McProtoNet.Core
{
	public enum DisconnectType
	{
		InGameKick,
		LoginRejected,
		ConnectionLost
	}
}
