﻿namespace McProtoNet.Core
{
	public enum Direction : byte
	{
		South = 3,
		West = 4,
		North = 2,
		East = 5,
		Up = 1,
		Down = 0
	}
}
