﻿namespace McProtoNet.Core
{
	public enum Hand : int
	{
		MAINHAND = 0,
		OFFHAND = 1
	}

}
