﻿namespace McProtoNet.Core
{
	public enum BlockFace : byte
	{
		DOWN = 0,
		UP = 1,
		NORTH = 2,
		SOUTH = 3,
		WEST = 4,
		EAST = 5,
		SPECIAL = 255
	}

}
