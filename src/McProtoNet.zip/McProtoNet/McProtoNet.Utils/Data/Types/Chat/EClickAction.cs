﻿namespace McProtoNet.Utils
{
	public enum EClickAction
	{
		OpenUrl,
		CopyToClipboard,
		RunCommand,
		SuggestCommand,
		ChangePage
	}
}
