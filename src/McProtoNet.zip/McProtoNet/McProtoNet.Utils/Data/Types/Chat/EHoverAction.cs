﻿namespace McProtoNet.Utils
{
	public enum EHoverAction
	{
		ShowText,
		ShowItem,
		ShowEntity
	}
}
