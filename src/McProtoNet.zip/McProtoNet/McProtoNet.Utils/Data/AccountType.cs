﻿namespace McProtoNet.Utils
{
	public enum AccountType
	{
		Microsoft,
		Mojang
	}
}