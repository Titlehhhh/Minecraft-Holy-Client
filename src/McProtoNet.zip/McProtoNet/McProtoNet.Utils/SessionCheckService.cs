﻿namespace McProtoNet.Utils
{
	public class SessionCheckService : ISessionCheckService
	{
		public Task<bool> Check(string uuid, string accesToken, string serverHash)
		{
			throw new NotImplementedException();
		}
	}
}