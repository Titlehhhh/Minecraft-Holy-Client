﻿namespace McProtoNet.Utils
{
	//public class TcpClientFactory : ITcpClientFactory
	//{
	//    public TcpClient CreateTcpClient(string host, ushort port)
	//    {
	//        return new TcpClient(host, port);
	//    }
	//}
}
