﻿namespace McProtoNet.Utils
{
	public class MicrosoftAuthService : IAuthService
	{
		public Task<LoginResponse> AuthAsync(AuthInfo authInfo)
		{
			throw new NotImplementedException();
		}
	}
}